@testable import BitTherapyMobile
import XCTest

final class BitTherapyMobileTests: XCTestCase {
    func testExample() throws {
        XCTAssert(true)
    }
}
