import XCTest

final class BitTherapyTests: XCTestCase {
    func testExample() throws {
        XCTAssert(true)
    }
}
