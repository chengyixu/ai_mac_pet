import Foundation
import Schwifty
import SwiftUI
import Swinject

class DeletePetUseCaseImpl: DeletePetUseCase {
    func safelyDelete(item: Species) -> Bool {
        false
    }
}
