import SwiftUI

extension Font {
    static var boldTitle: Font { .title.bold() }
}
