import SwiftUI

class StatusBarCoordinator {
    static let shared = StatusBarCoordinator()

    func show() {
        // ...
    }

    func hide() {
        // ...
    }
}
