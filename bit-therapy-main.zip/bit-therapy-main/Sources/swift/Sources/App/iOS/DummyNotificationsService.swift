import Foundation
import Schwifty

class NotificationsServiceImpl: NotificationsService {
    private let tag = "NotificationsServiceImpl"

    func start() {
        Logger.debug(tag, "Not available in iOS")
    }
}
