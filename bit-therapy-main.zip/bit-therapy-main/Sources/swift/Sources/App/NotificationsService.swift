import Foundation

protocol NotificationsService {
    func start()
}
